**Recent Changes**

- Added image sending support
- Added iOS password support
- Fixed special characters support